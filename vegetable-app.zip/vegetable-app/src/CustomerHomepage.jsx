import React from "react"
import { Link } from "react-router-dom"
export function CustomerHomePage()
{
    return(<div>
        <nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Vegetable Online Application</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
      <li class="nav-item">
          <Link class="nav-link" to="/home1">Home</Link>
        </li>
        <li class="nav-item">
          <Link class="nav-link" to="/contact1">Contact</Link>
        </li>




        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Vegetable
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            
            <li><Link class="dropdown-item" to="/view-all-veg1">View All Vegetable</Link></li>
            <li><Link class="dropdown-item" to="view-vegetable-by-Id1">View Vegetable By Id</Link></li>
            <li><a class="dropdown-item" href="#">View Vegetable By Category</a></li>
            <li><a class="dropdown-item" href="#">View Vegetable By Name</a></li>

          </ul>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Order
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><Link class="dropdown-item" to="/order1">Add Order</Link></li>
            <li><Link class="dropdown-item" to="/view-order">View Order</Link></li>
            <li><Link class="dropdown-item" to="/view-by-cusid">View Order by Customer Id</Link></li>

            <li><Link class="dropdown-item" to="/delete-order">Cancel order</Link></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Billing
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/billing1">Add Bill</Link></li>
            <li><Link class="dropdown-item" to="/view-bill1">View Bill</Link></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Feedback
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/view-feedback-by-vegId1">View FeedBack By Vegetable Id</Link></li>
              <li><Link class="dropdown-item" to="/feedback1">Add Feedback</Link></li>
            
          </ul>
          
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Cart
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/add-cart1">Add to Cart</Link></li>
              <li><Link class="dropdown-item" to="/delete1">Delete from cart</Link></li>
              <li><Link class="dropdown-item" to="/view-cart">View cart</Link></li>
            
          </ul>
          
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Customer </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><Link class="dropdown-item" to="/customer1">Add Details</Link></li>

            <li><Link class="dropdown-item" to="/delete-cus-by-id1">Delete My Account</Link></li>

          </ul>
        </li>
        
      </ul>
    </div>
  </div>
</nav>
    </div>

    )
}