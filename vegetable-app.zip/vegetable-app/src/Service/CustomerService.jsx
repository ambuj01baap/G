 import axios from 'axios'
export class CustomerService {
    url="http://localhost:8080/customer/save"
    addCustomer(customer)
    {
        return axios.post(this.url,customer)
    }
}
   export default new CustomerService()

