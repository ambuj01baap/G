import axios from 'axios'

const CUSTOMER_REST_API_URL="http://localhost:8080/customer/allcus";

class ViewAllCustomerService {
    getCustomers()
    {
       return axios.get(CUSTOMER_REST_API_URL);
    }
}
export default new ViewAllCustomerService();