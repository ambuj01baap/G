import axios from 'axios'
export class AddVegetableService {
    url="http://localhost:8080/vegetable/add"
    addVegetable(vegetable)
    {
        return axios.post(this.url,vegetable)
    }
}
   export default new AddVegetableService()

