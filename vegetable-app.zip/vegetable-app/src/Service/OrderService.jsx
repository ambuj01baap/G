import axios from 'axios'
export class OrderService {
    url="http://localhost:8080/Order/add"
    addOrder(order)
    {
        return axios.post(this.url,order)
    }
}
   export default new OrderService()

