import axios from 'axios'
export class FeedbackService {
    url="http://localhost:8080/feedback/add"
    addFeedback(feedback)
    {
        return axios.post(this.url,feedback)
    }
}
   export default new FeedbackService()

