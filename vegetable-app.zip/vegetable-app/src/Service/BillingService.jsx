import axios from 'axios'

export class BillingService
{
    url="http://localhost:8080/bill/add"
    addBill(bill)
    {
        return axios.post(this.url, bill)
    }
}
export default new BillingService()