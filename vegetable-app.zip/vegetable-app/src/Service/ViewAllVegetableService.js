import axios from 'axios'

const VEGETABLE_REST_API_URL="http://localhost:8080/vegetable/viewVegetables";

class ViewAllVegetableService {
    getVegtables()
    {
       return axios.get(VEGETABLE_REST_API_URL);
    }
}
export default new ViewAllVegetableService();