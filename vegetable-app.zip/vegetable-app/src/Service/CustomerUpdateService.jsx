import axios from "axios";

class CustomerUpdateService
{
    url="http://localhost:8080/customer/update/{cid}"
    updateCustomer(customer,cid)
    {
        return axios.put(this.url,customer,cid)
    }
}

export default new CustomerUpdateService()
