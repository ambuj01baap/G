import axios from 'axios'
export class CartService {
    url="http://localhost:8080/cart/save"
    addCart(Cart)
    {
        return axios.post(this.url,Cart)
    }
}
   export default new CartService()