import React from "react";
import ViewCartService from "./ViewCartService ";

class ViewAllCart extends React.Component{

  constructor(props)
  {
    super(props)
    this.state={
      cartitems:[]
    }

  }
  componentDidMount(){
    ViewCartService.getCartitems().then((response)=>{
      this.setState({cartitems: response.data})
    });
  }
  render()
  {
    return(
      <div>
        <h1 className="text-center">Cart  List</h1>
        <table className="table table-striped">
          <thead>
            <tr>
              <td>Cart Id </td>
              <td>Customer Id</td>
              <td>Vegetable </td>
              

            </tr>
          </thead>
          <tbody>
            {
              this.state.cartitems.map(
                cartitems=>
                <tr key={cartitems.cartId}>
                  <td>{cartitems.cartId}</td>
                 
                  <td>{cartitems.customerId}</td>
                  <td>{cartitems.vegetable}</td>
                  
                  </tr>

              )
            }
          </tbody>

        </table>

        </div>
    )
  }

}
export default ViewAllCart