import React from "react";
import ViewAllVegetableService from "../Service/ViewAllVegetableService";
class ViewAllVegetable extends React.Component{

  constructor(props)
  {
    super(props)
    this.state={
      vegetables:[]
    }

  }
  componentDidMount(){
    ViewAllVegetableService.getVegtables().then((response)=>{
      this.setState({vegetables : response.data})
    });
  }
  render() 
  {
    return(
      <div>
        <h1 className="text-center"><font color="#008000">Vegetable List</font></h1>
        <table className="table table-striped">
          <thead>
            <tr>
              <td>Vegetable Id</td>
              <td>Category</td>
              <td>Name</td>
              <td>Price</td>
              <td>Quantity</td>
              <td>Type</td>

            </tr>
          </thead>
          <tbody>
            {
              this.state.vegetables.map(
                vegetable=>
                  <tr key={vegetable.vegId}>
                  <td>{vegetable.vegId}</td>
                  <td>{vegetable.category}</td>
                  <td>{vegetable.name}</td>
                  <td>{vegetable.price}</td>
                  <td>{vegetable.quantity}</td>
                  <td>{vegetable.type}</td>
                  </tr>

              )
            }
          </tbody>

        </table>

        </div>
    )
  }

}
export default ViewAllVegetable