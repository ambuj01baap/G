import React from "react";


import '../App.css';
import { Admin } from '../Component/Admin';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import Contact from '../Component/Contact';
import Customer from '../Component/Customer';
import Feedback from '../Component/Feedback';
import Order from '../Component/Order';
import ViewAllCustomer from '../Component/ViewAllCustomer';
import AddVegetable from '../Component/AddVegetable';
import Billing from '../Component/Billing';
import ViewCustomerById from '../Component/ViewCustomerById';
import ViewCustomerByAddress from '../Component/ViewCustomerByAddress';
import DeleteCustomerById from '../Component/DeleteCustomerById';
import ViewFeedbackByVegId from '../Component/ViewFeedbackByVegId';
import ViewFeedbackByCustomerId from '../Component/ViewFeedbackByCustomerId';
import ViewAllVegetable from '../Component/ViewAllVegetable';
import CustomerUpdate from '../Component/CustomerUpdate';
import ViewVegetableById from '../Component/ViewVegetableById'
import DeleteVegetableById from '../Component/DeleteVegetableById';
import ViewBill from '../Component/ViewBill';
import { CustomerHomePage } from '../CustomerHomepage';
import ReactRouter from '../Component/ReactRouter';
import HomeNav from "./HomeNav";
import Cards from "./Cards";
import ViewAllOrder from "./ViewAllOrder";
import ViewOrderByCustomerId from "./ViewOrderByCustomerId";
import DeleteOrderById from "./DeleteOrderById";
import DeleteCartByVegId from "./DeleteCartByVegId ";
import Cart from "./Cart";
import ViewAllCart from "./ViewAllCarts (1)";
var sectionStyle = {
  width: "100%",
  height: "620px",
  
};
export function UserHomeRouter() {
  return (
    <Switch>
      <Route exact path="/user">
        <CustomerHomePage />
        <div
          id="intro-example"
          className="p-5 text-center bg-image"
          style={sectionStyle}
        >
          <h1><font color="#008000">
            <u>
              <i>Welcome user!!!</i>
            </u></font>
          </h1>
        </div>
      </Route>
      
      <Route exact path="/contact1">
        <CustomerHomePage />
        <Contact />
      </Route>
      <Route exact path="/customer1">
        <CustomerHomePage />
        <Customer />
      </Route>
      <Route exact path="/feedback1">
      <CustomerHomePage />
        <Feedback />
      </Route>
      <Route exact path="/order1">
      <CustomerHomePage />
        <Order />
      </Route>
      <Route exact path="/view-all-customer1">
      <CustomerHomePage />
        <ViewAllCustomer />
      </Route>
      <Route exact path="/vegetable1">
      <CustomerHomePage />
        <AddVegetable />
      </Route>
      <Route exact path="/billing1">
      <CustomerHomePage />
        <Billing />
      </Route>
      <Route exact path="/view-cus-by-id1">
      <CustomerHomePage />
        <ViewCustomerById />
      </Route>
      <Route exact path="/view-cus-by-address1">
      <CustomerHomePage />
        <ViewCustomerByAddress />
      </Route>
      <Route exact path="/view-feedback-by-vegId1">
      <CustomerHomePage />
        <ViewFeedbackByVegId />
      </Route>
      <Route exact path="/delete-cus-by-id1">
      <CustomerHomePage />
        <DeleteCustomerById />
      </Route>
      <Route exact path="/view-feedback-by-cusId1">
      <CustomerHomePage />
        <ViewFeedbackByCustomerId />
      </Route>
      <Route exact path="/view-all-veg1">
      <CustomerHomePage />
        <ViewAllVegetable/>
      </Route>
      <Route exact path="customer-update1">
      <CustomerHomePage />
        < CustomerUpdate/>
      </Route>
      <Route exact path="/view-vegetable-by-Id1">
      <CustomerHomePage />
        <ViewVegetableById />
      </Route>
      <Route exact path="/delete-vegetable-by-Id1">
      <CustomerHomePage />
        <DeleteVegetableById />
      </Route>
      <Route exact path="/view-bill1">
      <CustomerHomePage />
        <ViewBill />
      </Route>
      <Route exact path="/view-order">
      <CustomerHomePage />
        <ViewAllOrder />
      </Route>
      <Route exact path="/view-by-cusid">
      <CustomerHomePage />
        <ViewOrderByCustomerId />
      </Route>
      <Route exact path="/view-by-cusid">
      <CustomerHomePage />
        <ViewOrderByCustomerId />
      </Route>
      <Route exact path="/add-cart1">
      <CustomerHomePage />
        <Cart />
      </Route>
      <Route exact path="/view-cart">
      <CustomerHomePage />
        <ViewAllCart />
      </Route>
      
      <Route exact path="/delete1">
      <CustomerHomePage />
        <DeleteCartByVegId />
      </Route>
      <Route exact path="/home1">
        <CustomerHomePage />
        <Cards />
      </Route>

    </Switch>
  );
}

export default ReactRouter;
