import React,{ Component } from "react";
import OrderService from "../Service/OrderService"
export default class Order extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            orderNo:'',
            customerId:'',
            vegetableList:'',
           
            totalAmount:'',
            
            status:''
        }
    }
    handleorderNo=(event)=>
    {
        this.setState({
            orderNo:event.target.value
        })
    }
    handlecustomerId=(event)=>
    {
        this.setState({
            customerId:event.target.value
        })
    }
   
    handlelistOfVegetable=(event)=>
    {
        this.setState({
            vegetableList:event.target.value
        })
    }
    handletotalAmount=(event)=>
    {
        this.setState({
            totalAmount:event.target.value
        })
    }
    
    handleorderStatus=(event)=>
    {
        this.setState({
            status:event.target.value
        })
    }
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveOrder(this.state)      
    }
    saveOrder(order)
    {

        OrderService.addOrder(order).then( response=>
        {
        console.log(response)
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info">Order here</h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> Order  number</label>
                        <input  onChange={this.handleorderNo} value={this.state.orderNo}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Customer Id</label>
                        <input  onChange={this.handlecustomerId} value={this.state.customerId}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> list of vegetable </label>
                        <input onChange={this.handlelistOfVegetable} value={this.state.vegetableList} className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Total amount</label>
                        <input onChange={this.handletotalAmount} value={this.state.totalAmount} className="form-control"/>
                    </div>
                    
                    
                    <div className="form-group">
                        <label> orderStatus</label>
                        <input  onChange={this.handleorderStatus} value={this.state.status} className="form-control"/>
                    </div>
                    <button className="btn btn-primary mt-2">Order</button>
                </form>

            </div>
        )
    }

    }