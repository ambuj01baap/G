import React,{ Component } from "react";
import CartService from "../Service/CartService";
import CustomerService from "../Service/CartService"
export default class Cart extends Component{
    constructor(props)
    {
        super(props)
        this.state={
           cartId :'',
            customerId:'',
           vegetable:'',
    
            
        }
    }
    handleCartId=(event)=>
    {
        this.setState({
            cartId:event.target.value
        })
    }
    handleCustomerId=(event)=>
    {
        this.setState({
            customerId:event.target.value
        })
    }
    handleVegetable=(event)=>
    {
        this.setState({
            vegetable:event.target.value
        })
    }
   
    
    
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveCart(this.state)      
    }
    saveCart(Cart)
    {

        CartService.addCart(Cart).then( response=>
        {
        console.log(response)
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info"><font color="#008000">Add Customer</font></h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> Cart Id</label>
                        <input  onChange={this.handleCartId} value={this.state.cartId}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Customer Id</label>
                        <input  onChange={this.handleCustomerId} value={this.state.customerId}className="form-control"/>
                    </div>
                   
                    <div className="form-group">
                        <label> Vegetable </label>
                        <input  onChange={this.handleVegetable} value={this.state.vegetable} className="form-control"/>

                    </div>

                    <button className="btn btn-primary btn-success mt-2">Send Enquiry</button>
                </form>

            </div>
        )
    }

}