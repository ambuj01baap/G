import React from "react";
import { Route, Switch } from "react-router-dom";
import { useHistory } from "react-router-dom";
import HomeNav from "./HomeNav";
import Login1 from "./Login1";
import { Login2 } from "./Login2";


export default function LoginRouter() {
  const history = useHistory();
  return (
    <Switch>
      <Route exact path="/">
       <HomeNav/>
        <Login1 history={history} />
        <Login2 history={history}/>
      </Route>
    </Switch>
  );
}