import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function DeleteCartByCartId(){
    
        const[cartId,setcartId]=useState()
        const[Cart,setCart]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.delete(`http://localhost:8080/cart/cartId/${cartId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setCart(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3>Delete cart By Cart Id</h3>
                <hr/>
                <div className="form-group">
                    <label>cart ID</label>
                    <input value={cartId} onChange={(event)=>setcartId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(cartId)} className="btn btn-primary m-2">Delete</button>
                <hr/>
                {
                  Cart && <div>
                        <h3>Cart with Id: {cartId} is Deleted</h3>
                        
                        </div>
                }
            </div>
        )
    }