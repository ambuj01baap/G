import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewFeedbackByCustomerId(){
    
        const[customerId,setCustomerId]=useState()
        const[Feedback,setFeedback]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/feedback/customerId/${customerId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setFeedback(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3><font color="#008000">Get Feedback</font></h3>
                <hr/>
                <div className="form-group">
                    <label>Customer Id</label>
                    <input value={customerId} onChange={(event)=>setCustomerId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(customerId)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    Feedback && <div>
                        <h3>Customer Id: {customerId} Details</h3>
                        <ul className="list-group">
                            <li className="list-group-item list-group-item-success">Feedback Id: {Feedback.feedbackId}</li>
                            <li className="list-group-item list-group-item-success">Vegetable Id: {Feedback.vegetableId}</li>
                            <li className="list-group-item list-group-item-success">Rating: {Feedback.rating}</li>
                            <li className="list-group-item list-group-item-success">Comments: {Feedback.comments}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }