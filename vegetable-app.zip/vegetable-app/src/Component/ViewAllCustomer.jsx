import React from "react";
import ViewAllCustomerService from "../Service/ViewAllCustomerService";
class ViewAllCustomer extends React.Component{

  constructor(props)
  {
    super(props)
    this.state={
      customers:[]
    }

  }
  componentDidMount(){
    ViewAllCustomerService.getCustomers().then((response)=>{
      this.setState({customers : response.data})
    });
  }
  render()
  {
    return(
      <div>
        <h1 className="text-center"><font color="#008000">Customer List</font></h1>
        <table className="table table-striped">
          <thead>
            <tr>
              <td>Customer Id</td>
              <td>Name</td>
              <td>MobileNumber</td>
              <td>Email-Id</td>
              <td>Address</td>

            </tr>
          </thead>
          <tbody>
            {
              this.state.customers.map(
                customer=>
                <tr key={customer.customerId}>
                  <td>{customer.customerId}</td>
                  <td>{customer.name}</td>
                  <td>{customer.mobileNumber}</td>
                  <td>{customer.emailId}</td>
                  <td>{customer.address}</td>
                  </tr>

              )
            }
          </tbody>

        </table>

        </div>
    )
  }

}
export default ViewAllCustomer 