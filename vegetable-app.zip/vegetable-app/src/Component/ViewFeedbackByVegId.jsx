import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewFeedbackByVegId(){
    
        const[vegetableId,setVegetableId]=useState()
        const[Feedback,setFeedback]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/feedback/vegetableId/${vegetableId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setFeedback(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3>Get Feedback</h3>
                <hr/>
                <div className="form-group">
                    <label><font color="#008000">Vegetable Id</font></label>
                    <input value={vegetableId} onChange={(event)=>setVegetableId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(vegetableId)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    Feedback && <div>
                        <h3>Vegetable Id: {vegetableId} Details</h3>
                        <ul className="list-group">
                            <li className="list-group-item list-group-item-success">Feedback Id: {Feedback.feedbackId}</li>
                            <li className="list-group-item list-group-item-success">Customer  Id: {Feedback.customerId}</li>
                            <li className="list-group-item list-group-item-success">Rating: {Feedback.rating}</li>
                            <li className="list-group-item list-group-item-success">Comments: {Feedback.comments}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }