// import { render } from "@testing-library/react";
// import React,{Component} from "react";
// import Card from './card';
// import img1 from '../asset/onion.jpg';
// import img2 from '../asset/poto.jpg';
// import img3 from '../asset/spin.jpg';
// import img4 from '../asset/garli.jpg';
// import img5 from '../asset/ben.jpg';
// import img6 from '../asset/root.jpg';
// import img7 from '../asset/carr.jpg';
// import img8 from '../asset/bro.jpg';
// import img9 from '../asset/chilli.jpg';
// import img10 from '../asset/toto.jpg';



// class Home extends Component{
// render(){
//     return(
// <div className='container-fluid d-flex justify-content-center'>
//     <div className="row">
//         <div className="col-md-4">
//             <Card imgsrc={img1}title='Onion'/>
//         </div>
//         <div className="col-md-4">
//             <Card imgsrc={img2}title='Potato'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img3}title='Palak Spinch'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img4}title='Garlic'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img5}title='Beans'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img6}title='Betroot'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img7}title='Carrot'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img8}title='Broccoli'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img9}title='Green Chilly'/>
//         </div>
//         <div className="col-md-4">
//              <Card imgsrc={img10}title='Tomato'/>
//         </div>
//          </div>
// </div>
//     );
// }
// }
// export default Cards;