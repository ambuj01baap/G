import React,{ Component } from "react";
import CustomerService from "../Service/CustomerService"
export default class Customer extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            name:'',
            mobileNumber:'',
           emailId:'',
            address:''
            
        }
    }
    handleName=(event)=>
    {
        this.setState({
            name:event.target.value
        })
    }
    handleMobile=(event)=>
    {
        this.setState({
            mobileNumber:event.target.value
        })
    }
    handleEmail=(event)=>
    {
        this.setState({
            emailId:event.target.value
        })
    }
    handleAddress=(event)=>
    {
        this.setState({
            address:event.target.value
        })
    }
    
    
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveCustomer(this.state)      
    }
    saveCustomer(customer)
    {

        CustomerService.addCustomer(customer).then( response=>
        {
        console.log(response)
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info"><font color="#008000">Add Customer</font></h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> Name</label>
                        <input  onChange={this.handleName} value={this.state.name}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Mobile Number</label>
                        <input  onChange={this.handleMobile} value={this.state.mobileNumber}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Email-Id</label>
                        <input onChange={this.handleEmail} value={this.state.emailId} className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Address </label>
                        <input  onChange={this.handleAddress} value={this.state.address} className="form-control"/>

                    </div>

                    <button className="btn btn-primary btn-success mt-2">Send Enquiry</button>
                </form>

            </div>
        )
    }

}