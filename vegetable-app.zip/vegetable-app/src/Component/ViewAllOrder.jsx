import React from "react";
import ViewAllOrderService from "../Service/ViewAllOrderService";
class ViewAllOrder extends React.Component{

  constructor(props)
  {
    super(props)
    this.state={
      order:[]
    }

  }
  componentDidMount(){
    ViewAllOrderService.getCustomers().then((response)=>{
      this.setState({order : response.data})
    });
  }
  render()
  {
    return(
      <div>
        <h1 className="text-center">Order List</h1>
        <table className="table table-striped">
          <thead>
            <tr>
              <td>Order No</td>
              <td>Customer Id</td>
              <td>Vegetable List</td>
              
              <td>totalAmount</td>
              
              <td>status</td>

            </tr>
          </thead>
          <tbody>
            {
              this.state.order.map(
                order=>
                <tr key={order.orderNo}>
                  <td>{order.orderNo}</td>
                  <td>{order.customerId}</td>
                 
                  
                  <td>{order.vegetableList}</td>
                  <td>{order.totalAmount}</td>
                 
                  <td>{order.status}</td>
                  </tr>

              )
            }
          </tbody>

        </table>

        </div>
    )
  }

}
export default ViewAllOrder