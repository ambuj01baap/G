import React, {Component} from 'react'
import axios from 'axios'
import { useHistory, withRouter} from 'react-router'
import { NavLink } from 'react-router-dom'
export  class Login2 extends Component{
     
    constructor(props){
        super(props)
        this.state={
            name:'',
            password:'',
            successMsg:'',
            failedMsg:'',
            msg:'',
            loggedIn:''
        }
    }
    handlename=(event)=>
    {
        this.setState({
            name:event.target.value
        })


    }
    handleLogout=(event)=>
    {
        this.setState({loggedIn:''})
    }
    handlePassword=(event)=>
    {
        this.setState({
            password:event.target.value
        })

    }
    handleFormSubmission=(event)=>
    {
        event.preventDefault()
        axios.post('http://localhost:8080/admin/login',this.state).then((response)=>
        {   this.props.history.push("/")
            console.log(response.data.msg)
            if(response.data.msg!="Invalid credentials, try again!")
            {

                this.props.history.push("/")
            this.setState({
                name:'',
                password:'',
                successMsg:response.data.msg,
            loggedIn:true,
            })
            this.props.history.push("/user")
            }
            else{
                this.setState({
                    name:'',
                    password:'',
                    failedMsg:response.data.msg,
                    loggedIn:false
                })
            }
        }).catch(error=>{
            console.log(error)
            this.setState({
                name:'',
                password:'',
                msg:''})
        })
        
    }

    render(){
        if(!this.state.loggedIn)
        {

        
        return(
            <div className="container mt-3">
                
                <h2> User login Page</h2>
                <hr/>
                <form onSubmit={this.handleFormSubmission}>
                    <div className="form-group">
                        <label>
                            Username
                        </label>
                        <input onChange={this.handlename}value={this.state.name}className="form-control"/>
                      
                    </div>
                    <div>
                        <label>Password</label>
                        <input onChange={this.handlePassword}value={this.state.password} type="password" className="form-control"/>
                    </div>
                    <button type="submit"className="btn btn-success mt-2">login</button>
                </form>
                <hr/>
                <h5 className="text-danger">{this.state.failedMsg}</h5>
            </div>
        )
    }
    else{
        return(<div className='container'>
            <h2 >{this.state.successMsg}</h2>
            <button onClick={this.handleLogout} className="btn btn-danger" type="submit">Logout</button>
        </div>)
    }
}
}
export default withRouter(Login2);
