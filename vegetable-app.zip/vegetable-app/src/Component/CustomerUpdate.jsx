import React,{Component} from "react";
import CustomerUpdateService from "../Service/CustomerUpdateService";

export default class CustomerUpdate extends Component
{
    constructor(props){
        super(props)
        this.state =
        {   customerId:'',
            name:'',
            mobileNumber:'',
           emailId:'',
            address:''
        }
    }

    handlecustomerId=(event)=>
    {
        this.setState(
            {
                customerId:event.target.value
            }
        )
    }
    handlename=(event)=>
    {
        this.setState(
            {
                name:event.target.value
            }
        )
    }

    handlemobileNumber=(event)=>
    {
        this.setState(
            {
                mobileNumber:event.target.value
            }
        )
    }

    handleemailId=(event)=>
    {
        this.setState(
            {
                emailId:event.target.value
            }
        )
    }

    handleaddress=(event)=>
    {
        this.setState(
            {
                address:event.target.value
            }
        )
    }


    handleForSubmission=(event)=>
    {
        event.preventDefault()
        this.CustomerUpdate(this.state)
    }

    CustomerUpdate(customer,cid)
    {
        CustomerUpdateService.updateCustomer(customer,cid).then(response=>
            {
                console.log(response)
            }).catch(error=>console.log(error))
    }

    render()
    {
        return (
            <div>
            <h2 className="text-info">Update Customer Details</h2>
            <hr/>
            <form onSubmit={this.handleForSubmission}>
            <div className="form-group">
                    <label>Customer Id</label>
                    <input onChange={this.handlecustomerId} value={this.state.customerId} className="form-control"/>
                </div>
                <div className="form-group">
                    <label>Name</label>
                    <input onChange={this.handlename} value={this.state.name} className="form-control"/>
                </div>

                <div className="form-group">
                    <label>Mobile Number</label>
                    <input onChange={this.handlemobileNumber} value={this.state.mobileNumber} className="form-control"/>
                </div>

                <div className="form-group">
                    <label>Email-Id</label>
                    <input onChange={this.handleemailId} value={this.state.emailId} className="form-control"/>
                </div>

                <div className="form-group">
                    <label><address></address></label>
                    <input onChange={this.handleaddress} value={this.state.address} className="form-control"/>
                </div>


                <button className="btn btn-primary mt-2">Update</button>
            </form>
            </div>
        )
    }
}