import React,{useState,useEffect} from 'react'
import {useHistory} from 'react-router-dom'

export default function Login()
{
    const [username,setUsername]=useState("");
    const [password,setPassword]=useState("");

    const history=useHistory();
useEffect(()=>{

    if(localStorage.getItem('user-info')){
        history.push("/Admin")
    }
},[]    
)
async function Login(){
    console.warn(username,password)
    let item={username,password};
    let result = await fetch("http://localhost:8080/user/login",{
    method:"POST",
    headers:{
        "Content-Type":"application/json",
        "Accept":'application/json'
    },
    body:JSON.stringify(item)
    });
result=await result.json();
localStorage.setItem("user-info",JSON.stringify(result))
history.push("/Admin")

}
return(
    <div>
        <header>
            <h1> Login Page</h1>
            <div className="col-sm-6 offset-sm-3">
                <input type="text" placeholder="username" onChange={(e)=>setUsername(e.target.value)} className="form-control"/>
                <br/>
                <input type="text" placeholder="password" onChange={(e)=>setPassword(e.target.value)} className="form-control"/>
                <br/>
                <button onClick={Login} className="btn-btn-primary">Login</button>

            </div>
        </header>
    </div>
)
}