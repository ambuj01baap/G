import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewCustomerByAddress(){
    
        const[address,setaddress]=useState()
        const[Customer,setCustomer]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/customer/view/${address}`)
            .then(response=>
                {
                    console.log(response.data)
                    setCustomer(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3><font color="#008000">Get Customer</font></h3>
                <hr/>
                <div className="form-group">
                    <label>Customer Address</label>
                    <input value={address} onChange={(event)=>setaddress(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(address)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    Customer && <div>
                        <h3>Customer Address: {address} Details</h3>
                        <ul className="list-group">
                        <li className="list-group-item list-group-item-success">Customer id: {Customer.customerId}</li>
                            <li className="list-group-item list-group-item-success">Customer Name: {Customer.name}</li>
                            <li className="list-group-item list-group-item-success">Customer Mobile number: {Customer.mobileNumber}</li>
                            <li className="list-group-item list-group-item-success">Customer Email-Id: {Customer.emailId}</li>
                            <li className="list-group-item list-group-item-success">Customer Address: {Customer.address}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }