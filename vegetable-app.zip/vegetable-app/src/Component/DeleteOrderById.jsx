import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function DeleteOrderById(){
    
        const[orderNo,setOrderNo]=useState()
        const[Order,setOrder]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.delete(`http://localhost:8080/Order/orderNo/${orderNo}`)
            .then(response=>
                {
                    console.log(response.data)
                    setOrder(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3>Delete Order</h3>
                <hr/>
                <div className="form-group">
                    <label>Order ID</label>
                    <input value={orderNo} onChange={(event)=>setOrderNo(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(orderNo)} className="btn btn-primary m-2">Delete</button>
                <hr/>
                {
                  Order && <div>
                        <h3>Order with Id: {orderNo} is Deleted</h3>
                        
                        </div>
                }
            </div>
        )
    }