import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function DeleteCustomerById(){
    
        const[customerId,setCustomerId]=useState()
        const[Customer,setCustomer]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.delete(`http://localhost:8080/customer/delete/${customerId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setCustomer(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3><font color="#008000">Delete customer</font></h3>
                <hr/>
                <div className="form-group">
                    <label>Customer ID</label>
                    <input value={customerId} onChange={(event)=>setCustomerId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(customerId)} className="btn btn-primary m-2">Delete</button>
                <hr/>
                {
                  Customer && <div>
                        <h3>Customer with Id: {customerId} is Deleted</h3>
                        
                        </div>
                }
            </div>
        )
    }