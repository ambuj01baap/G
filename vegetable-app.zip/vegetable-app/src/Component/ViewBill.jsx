import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewBill(){
    
        const[billingId,setbillingId]=useState()
        const[Billing,setBilling]=useState({})
        
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/bill/viewBill/${billingId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setBilling(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3>Get Bill</h3>
                <hr/>
                <div className="form-group">
                    <label>Billing ID</label>
                    <input value={billingId} onChange={(event)=>setbillingId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(billingId)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    Billing && <div>
                        <h3>Billing ID: {billingId} Details</h3>
                        <ul className="list-group">
                            <li className="list-group-item list-group-item-success">Billing Address: {Billing.billingAddress}</li>
                            <li className="list-group-item list-group-item-success">Order Id: {Billing.orderId}</li>
                            <li className="list-group-item list-group-item-success">Transaction Date: {Billing.transactionDate}</li>
                            <li className="list-group-item list-group-item-success">Transaction Mode: {Billing.transactionMode}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }