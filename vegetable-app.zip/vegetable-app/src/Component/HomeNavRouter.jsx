import Cards from "./Cards";
import Contact from "./Contact";
import HomeNav from "./HomeNav";

export default function HomeNavRouter() {
    <switch>
    
      </switch>
}