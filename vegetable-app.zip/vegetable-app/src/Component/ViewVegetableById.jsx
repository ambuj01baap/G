import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewVegetableById(){
    
        const[vid,setVid]=useState()
        const[Vegetable,setVegetable]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/vegetable/vid${vid}`)
            .then(response=>
                {
                    console.log(response.data)
                    setVegetable(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3><font color="#008000">Get Vegetable</font></h3>
                <hr/>
                <div className="form-group" >
                    <label>Vegetable ID</label>
                    <input value={vid} onChange={(event)=>setVid(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(vid)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    Vegetable && <div>
                        <h3>Vegetable ID: {vid} Details</h3>
                        <ul className="list-group">
                            <li className="list-group-item list-group-item-success">Vegetable Category: {Vegetable.category}</li>
                            <li className="list-group-item list-group-item-success">Vegetable Name: {Vegetable.name}</li>
                            <li className="list-group-item list-group-item-success">Vegetable Price: {Vegetable.price}</li>
                            <li className="list-group-item list-group-item-success">Vegetable Quantity: {Vegetable.quantity}</li>
                            <li className="list-group-item list-group-item-success">Vegetable Type: {Vegetable.type}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }