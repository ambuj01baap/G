import axios from 'axios'

const CART_REST_API_URL="http://localhost:8080/cart/viewall";

class ViewCartService {
    getCartitems()
    {
       return axios.get(CART_REST_API_URL);
    }
}
export default new ViewCartService();