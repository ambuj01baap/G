import React, { Component } from 'react'
import BillingService from '../Service/BillingService'
export default class Billing extends Component {
    constructor(props) {
        super(props)
        this.state = {
            billingId: '',
            billingAddress: '',
            orderId: '',
            transactionDate: '',
            transactionMode: ''
        }
    }
    handleBillingId = (event) => {
        this.setState
            ({
                billingId: event.target.value
            })
    }
    handleBillingAddress = (event) => {
        this.setState
            ({
                billingAddress: event.target.value
            })
    }
    handleOrderId = (event) => {
        this.setState
            ({
                orderId: event.target.value
            })
    }
    handleTransactionDate = (event) => {
        this.setState
            ({
                transactionDate: event.target.value
            })
    }
    handleTransactionMode = (event) => {
        this.setState
            ({
                transactionMode: event.target.value
            })
    }
    handleFormSubmission = (event)=>
    {
        event.preventDefault()
    
        this.saveBill(this.state)
        //BillingService
    }

    saveBill(bill)
    {
         BillingService.addBill(bill).then(response =>
            {
                console.log(response)
             })
             .catch(error=>console.log(error))
     }
    render() {
        return (
            <div className="container">
                <h2 className="text-info">Welcome to Billing Section</h2>
                <hr />
                <form onSubmit={this.handleFormSubmission}>
                    <div className="form-group">
                        <label htmlFor="">Billing Id</label>
                        <input onChange={this.handleBillingId} value={this.state.billingId} className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Billing Address</label>
                        <input onChange={this.handleBillingAddress} value={this.state.billingAddress} className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Order Id</label>
                        <input onChange={this.handleOrderId} value={this.state.orderId} className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Transaction Date</label>
                        <input onChange={this.handleTransactionDate} value={this.state.transactionDate} className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Transaction Mode</label>
                        <input onChange={this.handleTransactionMode} value={this.state.transactionMode} className="form-control" />
                    </div>
                    <button className="btn btn-primary mt-3">Create</button>
                </form>
            </div>
        )
    }
}
