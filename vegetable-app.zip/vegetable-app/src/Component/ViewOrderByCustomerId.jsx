import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function ViewOrderByCustomerId(){
    
        const[customerId,setCustomerId]=useState()
        const[order,setOrder]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.get(`http://localhost:8080/Order/vieworder/${customerId}`)
            .then(response=>
                {
                    console.log(response.data)
                    setOrder(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3>Get Order</h3>
                <hr/>
                <div className="form-group">
                    <label>Customer Id</label>
                    <input value={customerId} onChange={(event)=>setCustomerId(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(customerId)} className="btn btn-primary m-2">Search</button>
                <hr/>
                {
                    order && <div>
                        <h3>Order Number: {customerId} Details</h3>
                        <ul className="list-group">
                        <li className="list-group-item list-group-item-success">orderNo: {order.orderNo}</li>
                            <li className="list-group-item list-group-item-success">customerId: {order.customerId}</li>
                            
                            <li className="list-group-item list-group-item-success">vegetableList: {order.vegetableList}</li>
                            <li className="list-group-item list-group-item-success">totalAmount: {order.totalAmount}</li>
                            
                            <li className="list-group-item list-group-item-success">status: {order.status}</li>
                        </ul>
                        </div>
                }
            </div>
        )
    }