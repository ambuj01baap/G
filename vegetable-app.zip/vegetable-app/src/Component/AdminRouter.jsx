import React from "react";
import { useHistory } from "react-router-dom";
import HomeNav from "./HomeNav";
import Home from "./Home";
import { Admin } from "./Admin";
import Login1 from "./Login1";

  
  import logo from '../logo.svg';
import '../App.css';
import {BrowserRouter as Router,Route,Switch} from 'react-router-dom'
import Contact from '../Component/Contact';
import Customer from '../Component/Customer';
import Feedback from '../Component/Feedback';
import Order from '../Component/Order';
import ViewAllCustomer from '../Component/ViewAllCustomer';
import AddVegetable from '../Component/AddVegetable';
import Billing from '../Component/Billing';
import ViewCustomerById from '../Component/ViewCustomerById';
import ViewCustomerByAddress from '../Component/ViewCustomerByAddress';
import DeleteCustomerById from '../Component/DeleteCustomerById';
import ViewFeedbackByVegId from '../Component/ViewFeedbackByVegId';
import ViewFeedbackByCustomerId from '../Component/ViewFeedbackByCustomerId';
import ViewAllVegetable from '../Component/ViewAllVegetable';
import CustomerUpdate from '../Component/CustomerUpdate';
import ViewVegetableById from '../Component/ViewVegetableById'
import DeleteVegetableById from '../Component/DeleteVegetableById';
import ViewBill from '../Component/ViewBill';
import { CustomerHomePage } from '../CustomerHomepage';
import Login from '../Component/Login'
import ReactRouter from '../Component/ReactRouter';
import HomeNavRouter from "./HomeNavRouter";
import Cards from "./Cards";
import DeleteOrderById from "./DeleteOrderById";
import ViewOrderByCustomerId from "./ViewOrderByCustomerId";
import ViewAllOrder from "./ViewAllOrder";
 var sectionStyle = {
  width: "100%",
  height: "620px",
  backgroundImage:"url('https://img.freepik.com/free-photo/chalkboard-with-different-colorful-healthy-vegetables-dark-background_114579-5472.jpg?size=626&ext=jpg')",

     
    };

export default function HomeRouter() {
  
 
  return (
    <Switch>
      <Route exact path="/Admin">
      <Admin/>
      <div
      
          id="intro-example"
          className="p-5 text-center bg-image"
          style={sectionStyle}

        >

          <h1>
            <u>
              <i>Welcome Admin!!!</i>
            </u>
          </h1>
        </div>
        
        </Route>
        <Route exact path="/contact">
        <Admin />
        <Contact />
      </Route>
      <Route exact path="/customer">
        <Admin />
        <Customer />
      </Route>
      <Route exact path="/feedback">
        <Admin />
        <Feedback />
      </Route>
      <Route exact path="/order">
        <Admin />
        <Order />
      </Route>
      <Route exact path="/view-all-customer">
        <Admin />
        <ViewAllCustomer />
      </Route>
      <Route exact path="/vegetable">
        <Admin />
        <AddVegetable />
      </Route>
      <Route exact path="/billing">
        <Admin />
        <Billing />
      </Route>
      <Route exact path="/view-cus-by-id">
        <Admin />
        <ViewCustomerById />
      </Route>
      <Route exact path="/view-cus-by-address">
        <Admin />
        <ViewCustomerByAddress />
      </Route>
      <Route exact path="/view-feedback-by-vegId">
        <Admin />
        <ViewFeedbackByVegId />
      </Route>
      <Route exact path="/delete-cus-by-id">
        <Admin />
        <DeleteCustomerById />
      </Route>
      <Route exact path="/view-feedback-by-cusId">
        <Admin />
        <ViewFeedbackByCustomerId />
      </Route>
      <Route exact path="/view-all-veg">
        <Admin />
        <ViewAllVegetable/>
      </Route>
      <Route exact path="customer-update">
        <Admin />
        < CustomerUpdate/>
      </Route>
      <Route exact path="/view-vegetable-by-Id">
        <Admin />
        <ViewVegetableById />
      </Route>
      <Route exact path="/delete-vegetable-by-Id">
        <Admin />
        <DeleteVegetableById />
      </Route>
      <Route exact path="/view-bill">
        <Admin />
        <ViewBill />
      </Route>
      <Route exact path="/home">
        <HomeNav />
        <Cards />
      </Route>
      <Route exact path="/view-order1">
      <Admin />
        <ViewAllOrder />
      </Route>
      <Route exact path="/view-by-cusid1">
      <Admin />
        <ViewOrderByCustomerId />
      </Route>
      <Route exact path="/view-by-cusid1">
      <Admin />
        <ViewOrderByCustomerId />
      </Route>
      <Route exact path="/delete-order1">
      <Admin />
        <DeleteOrderById />
      </Route>

    </Switch>
  );
}
