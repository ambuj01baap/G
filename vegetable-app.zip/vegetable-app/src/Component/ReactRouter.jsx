import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import AdminRouter from "./AdminRouter";
import LoginRouter from "./LoginRouter";
import { UserHomeRouter } from "./UserHomeRouter";

 export default function ReactRouter() {
  return (
    <Router>
      <LoginRouter />
      <AdminRouter />
      <UserHomeRouter/>
    </Router>
  );
}


