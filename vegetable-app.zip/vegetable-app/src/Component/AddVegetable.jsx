import React,{ Component } from "react";
import AddVegetableService from "../Service/AddVegetableService"
export default class AddVegetable extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            category:'',
            name:'',
            price:'',
            quantity:'',
            type:''
        }
    }
   
    handleCategory=(event)=>
    {
        this.setState({
            category:event.target.value
        })
    }
     handleName=(event)=>
    {
        this.setState({
            name:event.target.value
        })
    }
    handlePrice=(event)=>
    {
        this.setState({
            price:event.target.value
        })
    }
    handleQuantity=(event)=>
    {
        this.setState({
            quantity:event.target.value
        })
    }
     handleType=(event)=>
    {
        this.setState({
            type:event.target.value
        })
    }
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveVegetable(this.state)      
    }
    saveVegetable(vegetable)
    {

        AddVegetableService.addVegetable(vegetable).then( response=>
        {
        console.log(response)
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info"><font color="#008000">Add Vegetable</font></h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> Category </label>
                        <input  onChange={this.handleCategory} value={this.state.category}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Vegeatable Name</label>
                        <input  onChange={this.handleName} value={this.state.name}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Price </label>
                        <input onChange={this.handlePrice} value={this.state.price} className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Quantity </label>
                        <input  onChange={this.handleQuantity} value={this.state.quantity} className="form-control"/>

                    </div>
                     
                    <div className="form-group">
                        <label> Type </label>
                        <input  onChange={this.handleType} value={this.state.type} className="form-control"/>

                    </div>
                    <button className="btn btn-primary mt-2">Add</button>
                </form>

            </div>
        )
    }

}