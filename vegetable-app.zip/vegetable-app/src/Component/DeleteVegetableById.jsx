import axios from 'axios'
    import React , {useState,useEffect} from 'react'
    
    export default function DeleteVegetableById(){
    
        const[vid,setVid]=useState()
        const[Vgetetable,setVegetable]=useState({})
        const[idFromBtn,setIdFromBtn]=useState()
    
        useEffect(()=>
        {
            axios.delete(`http://localhost:8080/vegetable/vid${vid}`)
            .then(response=>
                {
                    console.log(response.data)
                    setVegetable(response.data)
                })
                .catch(error=>console.log(error))
        }, [idFromBtn]
        )
    
        return(
            <div>
                <h3><font color="#008000">Delete Vegetable</font></h3>
                <hr/>
                <div className="form-group">
                    <label>Vegetable ID</label>
                    <input value={vid} onChange={(event)=>setVid(event.target.value)} className="form-control"/>
    
                </div>
                <button onClick={ ()=>setIdFromBtn(vid)} className="btn btn-primary m-2">Delete</button>
                <hr/>
                {
                  Vgetetable && <div>
                        <h3>Vegetable with Id: {vid} is Deleted</h3>
                        
                        </div>
                }
            </div>
        )
    }