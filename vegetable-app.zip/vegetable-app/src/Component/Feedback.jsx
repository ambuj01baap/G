import React,{ Component } from "react";
import FeedbackService from "../Service/FeedbackService"
export default class Contact extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            customerId:'',
            vegetableId:'',
            rating:'',
            comments:''
        }
    }
    handleCustomerId=(event)=>
    {
        this.setState({
            customerId:event.target.value
        })
    }
    handleVegetableId=(event)=>
    {
        this.setState({
            vegetableId:event.target.value
        })
    }
    handleRating=(event)=>
    {
        this.setState({
            rating:event.target.value
        })
    }
    handleComments=(event)=>
    {
        this.setState({
            comments:event.target.value
        })
    }
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveFeedback(this.state)      
    }
    saveFeedback(feedback)
    {

        FeedbackService.addFeedback(feedback).then( response=>
        {
        console.log(response)
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info">Feedback</h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> Customer Id</label>
                        <input  onChange={this.handleCustomerId} value={this.state.customerId}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> vegetable Id</label>
                        <input  onChange={this.handleVegetableId} value={this.state.vegetableId}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Rating </label>
                        <input onChange={this.handleRating} value={this.state.rating} className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Email </label>
                        <input  onChange={this.handleComments} value={this.state.comments} className="form-control"/>

                    </div>
                    <button className="btn btn-primary mt-2">Send Feedback</button>
                </form>

            </div>
        )
    }

}