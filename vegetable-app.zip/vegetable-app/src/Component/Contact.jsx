import React,{ Component } from "react";
import ContactService from "../Service/ContactService"
export default class Contact extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            firstName:'',
            lastName:'',
            mobile:'',
            email:'',

        }
    }
    handleFirstName=(event)=>
    {
        this.setState({
            firstName:event.target.value
        })
    }
    handleLastName=(event)=>
    {
        this.setState({
            lastName:event.target.value
        })
    }
    handleMobile=(event)=>
    {
        this.setState({
            mobile:event.target.value
        })
    }
    handleEmail=(event)=>
    {
        this.setState({
            email:event.target.value
        })
    }
    handleForSubmit=(event)=>
    {
        event.preventDefault()
        this.saveCustomer(this.state)      
    }
    saveCustomer(contact)
    {

        ContactService.addContact(contact).then(response=>
        {
             console.log(response);
        this.setState({
          

        })
        }).catch(error=>console.log(error))

    }
    render()
    {
        
        return(
            <div className="container">
                <h2 className="text-info" >
                    <font color="#008000"> Contact Us</font></h2>
                <hr/>
                <form onSubmit={this.handleForSubmit}>
                    <div className="form-group">
                        <label> First Name</label>
                        <input  onChange={this.handleFirstName} value={this.state.firstName}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Last Name</label>
                        <input  onChange={this.handleLastName} value={this.state.lastName}className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Mobile</label>
                        <input onChange={this.handleMobile} value={this.state.Mobile} className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label> Email </label>
                        <input  onChange={this.handleEmail} value={this.state.email} className="form-control"/>

                    </div>
                    <button className="btn btn-primary btn-success mt-2">Send Enquiry</button>
                </form>
                
                

            </div>
        )
    }

}