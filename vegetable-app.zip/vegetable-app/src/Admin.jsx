import React from "react"
import { Link } from "react-router-dom"
export function Admin()
{
    return(<div>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Vegetable Online Application</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
      <li class="nav-item">
          <Link class="nav-link" to="/contact">contact</Link>
        </li>

 <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Customer </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><Link class="dropdown-item" to="/customer">Add Customer</Link></li>
            <li><Link class="dropdown-item" to="/view-all-customer">View all Customer</Link></li>
            <li><a class="dropdown-item" href="#">View Customer by Id</a></li>
            <li><a class="dropdown-item" href="#">View Customer by Location</a></li>
            <li><a class="dropdown-item" href="#">Delete Customer</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Vegetable
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/vegetable">Add Vegetable</Link></li>
            <li><a class="dropdown-item" href="#">Update Vegetable</a></li>
            <li><a class="dropdown-item" href="#">View All Vegetable</a></li>
            <li><a class="dropdown-item" href="#">View Vegetable By Category</a></li>
            <li><a class="dropdown-item" href="#">Remove Vegetable</a></li>
            <li><a class="dropdown-item" href="#">View Vegetable By Category</a></li>
          </ul>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Order
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <li><Link class="dropdown-item" to="/order">Add Order</Link></li>
            <li><a class="dropdown-item" href="#">View Order</a></li>
            <li><a class="dropdown-item" href="#">View Order by Customer Id</a></li>
            <li><a class="dropdown-item" href="#">View Order by Id</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Billing
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><Link class="dropdown-item" to="/billing">Add Bill</Link></li>
            <li><a class="dropdown-item" href="#">View Bill</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Feedback
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="#">View FeedBack By Vegetable Id</a></li>
              <li><Link class="dropdown-item" to="/feedback">Add Feedback</Link></li>
            <li><a class="dropdown-item" href="#">View Feedback by Customer Id</a></li>
            <li><a class="dropdown-item" href="#">View Order by Id</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </div>

    )
}